package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Demo4
 */
@WebServlet("/Demo4")
public class Demo4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		String[] subjects={"English","Physics","Maths"};
		double[] marks={90.0,95.0,100.0};
		  response.setContentType("text/html");
		  
		  out.print("<table>");
		  
		  
			 out.print("<tr>");
			  out.print("<td>"+"Subjects"+"</td>");
			  out.print("<td>"+"Marks"+"</td>");
			  out.println("</tr>");
			  
		double sum=0;
		  for (int i=0;i<subjects.length;i++) {
			  out.print("<tr>");
			  out.print("<td>"+subjects[i]+"</td>");
			  out.print("<td>"+marks[i]+"</td>");
			  out.println("</tr>");
			  sum = sum+marks[i];
		  }
		 
		  double average;
		  
		 average = sum/subjects.length+1;
		 out.print("<tr>");
		 out.print("<td>"+"Total Marks"+"</td>");
		
		 out.println("<td>"+sum+"</td>");
		 out.println("</tr>");
		 
		 out.print("<tr>");
		 out.print("<td>"+"Average"+"</td>");
		
		 out.println("<td>"+average+"</td>");
		 out.print("</tr>");
		 
		 
		 
                  out.println("</table>");
}
}